package com.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson7GraphQlDemoCustomerWithAddressApplicationTests {

	@Test
	void contextLoads() {
	}

}
