package com.bankapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab7Part2Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab7Part2Application.class, args);
    }

}
