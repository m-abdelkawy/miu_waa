package com.calculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab6Part2Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab6Part2Application.class, args);
	}

}
