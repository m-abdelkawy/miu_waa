package com.mongodemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson5MongoDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson5MongoDemoApplication.class, args);
	}

}
