package com.mongodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson5MongoDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
