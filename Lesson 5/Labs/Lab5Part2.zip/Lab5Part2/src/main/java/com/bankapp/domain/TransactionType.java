package com.bankapp.domain;

public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL
}
