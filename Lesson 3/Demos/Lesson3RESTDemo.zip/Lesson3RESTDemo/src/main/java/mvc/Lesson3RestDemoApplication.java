package mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson3RestDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson3RestDemoApplication.class, args);
	}

}
