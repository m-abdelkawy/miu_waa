package mvc.models;

public class Bank {

}
