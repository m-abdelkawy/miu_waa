package mvc.models;

public enum TransactionType {
        DEPOSIT,
        WITHDRAWAL
}
