package mvc.domain;

public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL
}
