import logo from './logo.svg';
import './App.css';
import { TaskLists } from './components/TaskLists';

function App() {
  return (
    <div>
      <TaskLists/>
    </div>
  );
}

export default App;
